import httpx
import base64
from solana.transaction import Transaction
from solana.rpc.api import Client

req = "https://quote-api.jup.ag/v6/quote?inputMint=So11111111111111111111111111111111111111112&outputMint=EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v&amount=1000&slippageBps=1"

quote_response = httpx.get(url=req).json()

print(quote_response)

wallet_key = 'CqCGrgU9pMTd1q3V3eB99ccgdd61KMsiFJr8Wb9LMtjM'
user_public_key = str(wallet_key)

swap_data = {
    "quoteResponse": quote_response,
    "userPublicKey": str(wallet_key),
    "wrapUnwrapSOL": True
}

get_swap_data = httpx.post(url="https://quote-api.jup.ag/v6/swap", json=swap_data).json()
print(get_swap_data)

# Assuming get_swap_data['swapTransaction'] contains the base64-encoded serialized transaction
swap_transaction_base64 = get_swap_data['swapTransaction']
swap_transaction_bytes = base64.b64decode(swap_transaction_base64)
transaction = Transaction.deserialize(swap_transaction_bytes)
#print(transaction)

# Sign the transaction (add the wallet key or private key used for signing)
wallet_key_bytes = bytes.fromhex(wallet_key)
transaction.sign([wallet_key_bytes])  # Use the key for signing

# Serialize the transaction
raw_transaction = transaction.serialize()

# Create a Solana RPC connection (assuming you have the necessary variables initialized)
rpc_url = "https://api.mainnet-beta.solana.com"
connection = Client(rpc_url)

# Send the raw transaction
txid = connection.send_raw_transaction(raw_transaction, skip_preflight=True, max_retries=2)
print(f"https://solscan.io/tx/{txid}")

# Confirm the transaction
confirmed_tx = connection.confirm_transaction(txid)
print(f"Transaction confirmed: {confirmed_tx}")

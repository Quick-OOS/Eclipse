import httpx
import base64
import base58
from solana.transaction import Transaction
from solana.keypair import Keypair
from solana.transaction import Transaction

# Existing code

req = "https://quote-api.jup.ag/v6/quote?inputMint=So11111111111111111111111111111111111111112&outputMint=EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v&amount=1000&slippageBps=1"
quote_response = httpx.get(url=req).json()
print(quote_response)

import httpx
import base64
from solana.transaction import Transaction

# Existing code

req = "https://quote-api.jup.ag/v6/quote?inputMint=So11111111111111111111111111111111111111112&outputMint=EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v&amount=1000&slippageBps=1"
quote_response = httpx.get(url=req).json()
#print(quote_response)

wallet_key = 'CqCGrgU9pMTd1q3V3eB99ccgdd61KMsiFJr8Wb9LMtjM'
user_public_key = str(wallet_key)

swap_data = {
    "quoteResponse": quote_response,
    "userPublicKey": str(wallet_key),
    "wrapUnwrapSOL": True
}

get_swap_data = httpx.post(url="https://quote-api.jup.ag/v6/swap", json=swap_data).json()
print(get_swap_data)


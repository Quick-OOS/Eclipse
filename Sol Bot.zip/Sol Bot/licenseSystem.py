def check_license(license_key):
    valid_license = "JYFUSF754GYTV"  # Replace this with your valid license key

    if license_key == valid_license:
        return True
    else:
        return False

def main():
    user_license = input("Enter your license key: ")

    if check_license(user_license):
        print("License is valid. Enjoy your program!")
    else:
        print("Invalid license. Please enter a valid license key.")

if __name__ == "__main__":
    main()

from solana.account import Account
from solana.rpc.api import Client
from solana.system_program import transfer
from solana.rpc.types import TxOpts

def send_tokens(sender_private_key, recipient_public_keys, amount_in_sol):
    # Connect to Solana RPC endpoint
    solana_client = Client("https://api.mainnet-beta.solana.com")

    # Load sender's account
    sender_account = Account(sender_private_key)

    # Convert dollar amount to lamports (1 SOL = 1,000,000,000 lamports)
    lamports_amount = int(amount_in_sol * 1000000000)

    # Iterate through recipients and send tokens
    for recipient_public_key in recipient_public_keys:
        transaction = transfer(sender_account, recipient_public_key, lamports_amount, opts=TxOpts(skip_confirmation=False))
        tx_hash = solana_client.send_transaction(transaction, sender_account)
        print(f"Sent {amount_in_sol} SOL to {recipient_public_key}. Transaction hash: {tx_hash}")

def main():
    sender_private_key = "SENDER_PRIVATE_KEY"  # Replace with your sender's private key
    recipient_public_keys = ["RECIPIENT_PUBLIC_KEY_1", "RECIPIENT_PUBLIC_KEY_2"]  # Add recipient public keys
    amount_to_send = 1.0  # Specify the amount in SOL to send

    send_tokens(sender_private_key, recipient_public_keys, amount_to_send)

if __name__ == "__main__":
    main()
